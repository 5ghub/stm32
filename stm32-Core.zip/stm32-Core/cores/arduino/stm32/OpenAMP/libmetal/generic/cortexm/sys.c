#ifdef VIRTIOCON

#include "libmetal/lib/system/generic/template/sys.c"

#endif /* VIRTIOCON */
