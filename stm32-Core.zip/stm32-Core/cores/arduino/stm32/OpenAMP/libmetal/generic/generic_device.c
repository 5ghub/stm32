#ifdef VIRTIOCON

#include "libmetal/lib/system/generic/generic_device.c"

#endif /* VIRTIOCON */
